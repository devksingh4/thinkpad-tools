# thinkpad_tools_assets.utils.py


class ApplyValueFailedException(Exception):
    """
    Exception raised when failed to apply settings
    """
    pass


class NotSudo(Exception):
    pass
